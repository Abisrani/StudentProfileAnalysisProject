from django.apps import AppConfig


class PredictiveAcceptanceConfig(AppConfig):
    name = 'PredictiveAcceptance'
